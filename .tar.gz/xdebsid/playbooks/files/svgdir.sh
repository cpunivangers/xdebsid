#!/bin/sh

if [ -z $1 ]; then
  DIRSVG=$(basename $(pwd))
  cd ..
  echo Répertoire à sauvegarder : $DIRSVG
else
	DIRSVG=$1
fi
if [ ! -d $DIRSVG ]; then
	echo "Répertoire $DIRSVG inexistant ..."
	exit 1
fi

echo "tar --exclude .git -zcvf  $DIRSVG.tar.gz $DIRSVG"
tar --exclude .git -zcvf $DIRSVG.tar.gz $DIRSVG

OPTRSYNC="--progress --delete --exclude .git -av"

# Partages AD
PATH_SAMI="$HOME/UA_PersonnelsDDN/DDN-SAMI/SitesUniversite/IUT"
echo "rsync $OPTRSYNC $DIRSVG $PATH_SAMI/ansible/"
rsync $OPTRSYNC $DIRSVG $PATH_SAMI/ansible/

# UAbox
PATH_UABOX=$(grep "localPath" ~/.config/ownCloud/owncloud.cfg | grep "Logiciels" | cut -d= -f2)

if [ -z "$PATH_UABOX" ] ; then
	exit 1
fi

echo $DIRSVG.tar.gz $PATH_UABOX/ansible/
cp -f $DIRSVG.tar.gz $PATH_UABOX/ansible/

echo "rsync $OPTRSYNC $DIRSVG $PATH_UABOX/ansible/"
rsync $OPTRSYNC $DIRSVG $PATH_UABOX/ansible/

# ShadowDrive
PATH_SHADOWDRIVE=$(grep "localPath" ~/.config/Shadow\ Drive/shadow-drive.cfg | cut -d= -f2)

if [ -z "$PATH_SHADOWDRIVE" ] ; then
	exit 1
fi
if [ ! -d $PATH_SHADOWDRIVE ]; then
	exit 1
fi
echo $DIRSVG.tar.gz $PATH_SHADOWDRIVE/ansible/
cp -f $DIRSVG.tar.gz $PATH_SHADOWDRIVE/ansible/
echo "rsync $OPTRSYNC $DIRSVG $PATH_SHADOWDRIVE/ansible/"
rsync $OPTRSYNC $DIRSVG $PATH_SHADOWDRIVE/ansible/

# Github
if [ ! -f "$DIRSVG/razgit.sh" ] ; then
	exit 1
fi
cd $DIRSVG
echo "razgit.sh"
bash razgit.sh

exit
